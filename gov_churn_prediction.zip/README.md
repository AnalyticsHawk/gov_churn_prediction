# Predicting Public Service Disengagement with Azure ML

This project demonstrates an end-to-end machine learning solution using Azure ML to predict disengagement (churn) in public programs.